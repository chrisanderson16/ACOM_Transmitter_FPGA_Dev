clear all; close all;

[LFM, FsLFM] = audioread('../LFM/chirp_sounder_aquatron_Tsymb_0.2.wav');
LFM = LFM(1:length(LFM)/2);
% FSK_filt = do_BPF_Filter(FSK);
Fs = 96000;

guard = zeros(10*FsLFM-length(LFM), 1);

original = [LFM; guard; LFM];
spectrogram(original, 2048, 512, 2048, 96000);


% this is the auto-correlation - the separation should be 96000 (one
% second)
[xc_org, xc_idx_org] = xcorr(original);


% resample 
P = 5000;
Q = 5003;
compressed = resample(original, P, Q);


% comparison betwen the two autocorrelations
% zooming into the second peak on the far right, the difference 
% in time lag is equivalent to the Doppler scaling factor (1-P/Q)
% note that the negative lags are not represented.   
[xc_comp, xc_idx_comp] = xcorr(compressed);
plot(xc_idx_org, xc_org, xc_idx_comp, xc_comp)
legend('original', 'compressed')
xlabel('time index n');
ylabel('Autocorrelation Rxx(n)')
grid
ax = axis; ax(2) = xc_idx_org(end); ax(1) = 0; axis(ax);


%% code to write to wavefile and plot the spectrogram
to_daq = int16(compressed./max(abs(compressed))*(2^15-1));
audiowrite('for_dsc.wav', to_daq, FsLFM);




